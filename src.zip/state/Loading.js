import { atom } from 'recoil';

export default atom({ key: 'LoadingState', default: false });
