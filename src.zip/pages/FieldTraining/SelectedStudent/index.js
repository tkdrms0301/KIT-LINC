import { Grid, Typography } from '@mui/material';
import MainCard from 'components/MainCard';
const SelectedStudentList = () => {
    return (
        <Grid>
            <MainCard>
                <Typography variant="h2">현장실습생 선발조회(학생)</Typography>
            </MainCard>
        </Grid>
    );
};
export default SelectedStudentList;
