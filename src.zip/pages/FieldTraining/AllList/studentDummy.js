const studentRows = [
    {
        id: 1,
        major: '기계공학과',
        grade: '4학년',
        name: 'AAA',
        isSelected: '',
        drop: ''
    },
    {
        id: 2,
        major: '기계공학과',
        grade: '2학년',
        name: 'BBB',
        isSelected: '',
        drop: ''
    },
    {
        id: 3,
        major: '컴퓨터소프트웨어공학과',
        grade: '4학년',
        name: 'CCC',
        isSelected: '',
        drop: ''
    },
    {
        id: 4,
        major: '전자공학부',
        grade: '3학년',
        name: 'DDD',
        isSelected: '',
        drop: ''
    },
    {
        id: 5,
        major: '컴퓨터공학과',
        grade: '1학년',
        name: 'EEE',
        isSelected: '',
        drop: ''
    },
    {
        id: 6,
        major: '컴퓨터공학과',
        grade: '1학년',
        name: 'EEE',
        isSelected: '',
        drop: ''
    },
    {
        id: 7,
        major: '컴퓨터공학과',
        grade: '1학년',
        name: 'EEE',
        isSelected: '',
        drop: ''
    }
];
export default studentRows;
