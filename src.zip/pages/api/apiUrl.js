const BASE_URL = 'http://337se.duckdns.org:80/';
export default BASE_URL;
