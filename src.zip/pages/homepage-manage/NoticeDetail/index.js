const NoticeDetail = () => {
    return 'notice detail';
};
