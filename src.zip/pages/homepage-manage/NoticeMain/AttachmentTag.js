import { Grid } from '@mui/material';
const AttachmentTag = ({ imageFileName }) => {
    return <Grid>{imageFileName}</Grid>;
};

export default AttachmentTag;
