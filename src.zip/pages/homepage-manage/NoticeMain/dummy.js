// Mock Data
const posts = [
    {
        postId: 1,
        title: 'K-기대함 프로젝트',
        attachment: true,
        author: '안상근',
        registrationDate: '2022-09-05',
        view: 5
    },
    {
        postId: 2,
        title: '공지사항2',
        attachment: false,
        author: '안상근2',
        registrationDate: '2022-09-05',
        view: 7
    },
    {
        postId: 3,
        title: '공지사항3',
        attachment: true,
        author: '안상근3',
        registrationDate: '2022-09-05',
        view: 4
    },
    {
        postId: 4,
        title: '공지사항4',
        attachment: false,
        author: '안상근4',
        registrationDate: '2022-09-05',
        view: 10
    },
    {
        postId: 5,
        title: '공지사항5',
        attachment: true,
        author: '안상근5',
        registrationDate: '2022-09-05',
        view: 9
    },
    {
        postId: 6,
        title: '공지사항6',
        attachment: true,
        author: '안상근6',
        registrationDate: '2022-09-05',
        view: 5
    },
    {
        postId: 7,
        title: '공지사항7',
        attachment: false,
        author: '안상근7',
        registrationDate: '2022-09-05',
        view: 5
    },
    {
        postId: 8,
        title: '공지사항8',
        attachment: true,
        author: '안상근8',
        registrationDate: '2022-09-05',
        view: 11
    },
    {
        postId: 9,
        title: '공지사항9',
        attachment: true,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 10,
        title: '공지사항9',
        attachment: false,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 11,
        title: '공지사항9',
        attachment: true,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 12,
        title: '공지사항9',
        attachment: true,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 13,
        title: '공지사항9',
        attachment: false,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 14,
        title: '공지사항9',
        attachment: true,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 15,
        title: '공지사항9',
        attachment: true,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 16,
        title: '공지사항9',
        attachment: true,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 17,
        title: '공지사항9',
        attachment: false,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 18,
        title: '공지사항9',
        attachment: true,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 19,
        title: '공지사항9',
        attachment: true,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    },
    {
        postId: 20,
        title: '공지사항9',
        attachment: false,
        author: '안상근9',
        registrationDate: '2022-09-05',
        view: 21
    }
];

export default posts;
