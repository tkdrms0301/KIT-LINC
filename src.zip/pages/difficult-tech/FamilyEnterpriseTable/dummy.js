// Mock Data
const enterpriseRows = [
    {
        companyId: 1,
        companyName: 'Intelli K',
        companyType: '2',
        category: '2',
        growthDegree: '3'
    },
    {
        companyId: 2,
        companyName: '회사 이름2',
        companyType: '2',
        category: '2',
        growthDegree: '4'
    },
    {
        companyId: 3,
        companyName: '회사 이름3',
        companyType: '2',
        category: '3',
        growthDegree: '2'
    },
    {
        companyId: 4,
        companyName: '회사 이름4',
        companyType: '2',
        category: '4',
        growthDegree: '2'
    },
    {
        companyId: 5,
        companyName: '회사 이름5',
        companyType: '2',
        category: '5',
        growthDegree: '2'
    },
    {
        companyId: 6,
        companyName: '회사 이름6',
        companyType: '2',
        category: '2',
        growthDegree: '2'
    }
];

export default enterpriseRows;
