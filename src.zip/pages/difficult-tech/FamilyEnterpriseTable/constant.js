const companyTypeList = ['대기업', '중소기업'];
const categoryList = ['IT분야', '그린에너지분야', '음식료', '섬유의복', '목제종이', '석유화학', '비금속', '운송장비'];
const growthDegreeList = ['창업기', '초기성장기', '성장기', '성숙기', '업종전환기'];
const list = {
    companyTypeList: ['대기업', '중소기업'],
    categoryList: ['IT분야', '그린에너지분야', '음식료', '섬유의복', '목제종이', '석유화학', '비금속', '운송장비'],
    growthDegreeList: ['창업기', '초기성장기', '성장기', '성숙기', '업종전환기']
};
export { companyTypeList, categoryList, growthDegreeList, list };
