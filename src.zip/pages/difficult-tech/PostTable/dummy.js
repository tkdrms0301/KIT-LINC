// Mock Data
const post = [
    {
        title: '프로젝트 이름1',
        content: '아녕안녕아녕안녕아녕안녕아녕안녕아녕안녕아녕안녕아녕안녕아녕안녕녕안녕아녕안녕아녕안녕아녕안녕아녕안녕아녕안녕아녕안녕',
        tags: ['프로젝트 태그1', '프로젝트 태그2'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름2',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그3', '프로젝트 태그2'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름3',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그1', '프로젝트 태그3'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름4',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그3', '프로젝트 태그4'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름5',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그3', '프로젝트 태그4'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름6',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그3', '프로젝트 태그4'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름7',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그3', '프로젝트 태그4'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름8',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그3', '프로젝트 태그4'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름9',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그3', '프로젝트 태그4'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름10',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그3', '프로젝트 태그4'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름11',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그3', '프로젝트 태그4'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    },
    {
        title: '프로젝트 이름12',
        content: '프로젝트 설명',
        tags: ['프로젝트 태그3', '프로젝트 태그4'],
        company: {
            name: '회사 이름',
            logo: '회사 로고',
            address: '회사 주소'
        },
        date: '2020-01-01'
    }
];

export default post;
