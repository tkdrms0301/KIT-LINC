import React from 'react';

const DifficultTech = () => {
    return (
        <div>
            <h1>hello</h1>
        </div>
    );
};

export default DifficultTech;
