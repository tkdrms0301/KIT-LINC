import React from 'react';
import FormDialog from './ApproveProject/FormDialog';

const DifficultTech = () => {
    return (
        <div>
            <h1>
                <FormDialog></FormDialog>
            </h1>
        </div>
    );
};

export default DifficultTech;
